local colorLamp=table.deepcopy(data.raw["lamp"]["small-lamp"])
colorLamp.name="qwrt-lamp"
local lampItem=table.deepcopy(data.raw["item"]["small-lamp"])
lampItem.name="qwrt-lamp"
colorLamp.minable.result="qwrt-lamp"
lampItem.place_result="qwrt-lamp"
colorLamp.picture_on={filename="__QwrtLamp__/blank.png",size=32}
colorLamp.circuit_connector_sprites=nil

lampItem.icons={{icon="__base__/graphics/icons/small-lamp.png",icon_size=64,icon_mipmaps=4,scale=0.5},
{icon="__base__/graphics/icons/signal/signal_red.png",icon_size=64,icon_mipmaps=4,scale=0.15,shift={-7,-7}},
{icon="__base__/graphics/icons/signal/signal_green.png",icon_size=64,icon_mipmaps=4,scale=0.15,shift={-9,0}},
{icon="__base__/graphics/icons/signal/signal_blue.png",icon_size=64,icon_mipmaps=4,scale=0.15,shift={-7,7}},
}

data:extend{
  colorLamp,
  lampItem,
  {
    type="recipe",
    name="qwrt-lamp",
    ingredients={{"small-lamp",1},{"electronic-circuit",1}},
    result="qwrt-lamp",
    enabled=false,
  },
  {
    type="simple-entity-with-owner",
    name="lamp-light",
    flags={"placeable-off-grid"},
    render_layer="higher-object-under",
    picture={
      filename = "__base__/graphics/entity/small-lamp/lamp-light.png",
      priority = "high",
      width = 46,
      height = 40,
      frame_count = 1,
      axially_symmetrical = false,
      direction_count = 1,
      shift = util.by_pixel(0, -7),
      draw_as_glow=true,
      apply_runtime_tint = true,
      hr_version =
      {
        filename = "__base__/graphics/entity/small-lamp/hr-lamp-light.png",
        priority = "high",
        width = 90,
        height = 78,
        frame_count = 1,
        axially_symmetrical = false,
        direction_count = 1,
        shift = util.by_pixel(0, -7),
        scale = 0.5,
        draw_as_glow=true,
        apply_runtime_tint = true,
      }
    },
  }
}
table.insert(data.raw["technology"]["circuit-network"].effects,{type="unlock-recipe",recipe="qwrt-lamp"})
