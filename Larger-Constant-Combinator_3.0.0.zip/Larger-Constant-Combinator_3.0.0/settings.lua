data:extend({
    {
        type = "int-setting",
        name = "Larger_Constant_Combinator_Rows",
        default_value = 8,
        minimum_value = 4,
        maximum_value = 50,
        setting_type = "startup",
        order = "a",
    },
})