script.on_event(defines.events.on_tick,
  function(event)
    for _, surface in pairs(game.surfaces) do
      for _, lamp in pairs(surface.find_entities_filtered({name="qwrt-lamp"})) do
        for _, light in pairs(lamp.surface.find_entities_filtered({name="lamp-light",area={{lamp.position.x-0.01,lamp.position.y-0.01},{lamp.position.x+0.01,lamp.position.y+0.01}}})) do
          --light.color={r=lamp.get_circuit_network(defines.wire_type.red).get_signal{type="virtual",name="red"},g=100,b=0}
          if(lamp.is_connected_to_electric_network()) then
            if(lamp.get_circuit_network(defines.wire_type.red)) then
              local network = lamp.get_circuit_network(defines.wire_type.red)
              if (not lamp.get_control_behavior().disabled) then light.color={r=math.min(network.get_signal{type="virtual",name="signal-red"},255),g=math.min(network.get_signal{type="virtual",name="signal-green"},255),b=math.min(network.get_signal{type="virtual",name="signal-blue"},255)} else light.color={50,50,50} end
            elseif(lamp.get_circuit_network(defines.wire_type.green)) then
              local network = lamp.get_circuit_network(defines.wire_type.green)
              if (not lamp.get_control_behavior().disabled) then light.color={r=math.min(network.get_signal{type="virtual",name="signal-red"},255),g=math.min(network.get_signal{type="virtual",name="signal-green"},255),b=math.min(network.get_signal{type="virtual",name="signal-blue"},255)} else light.color={50,50,50} end
            else
              light.color={50,50,50}
            end
          else
            light.color={50,50,50}
          end
        end
      end
    end
  end
)

function OnEntityCreated(event)
  local newLamp = event.created_entity or event.entity
  if(newLamp.name=="qwrt-lamp") then
    newLamp.surface.create_entity{name="lamp-light",position=newLamp.position,force="neutral"}
  end
end

function OnEntityRemoved(event)
  local newLamp = event.entity
  if(newLamp.name=="qwrt-lamp") then
    for _, light in pairs(newLamp.surface.find_entities_filtered({name="lamp-light",area = {
				{ x = newLamp.position.x - 0.1, y = newLamp.position.y - 0.1 },
				{ x = newLamp.position.x + 0.1, y = newLamp.position.y + 0.1 },
			},})) do
      light.destroy()
    end
  end
end

function move_lamp(event)
  local lamp = event.moved_entity
  if(lamp.name=="qwrt-lamp") then
    for _, light in pairs(lamp.surface.find_entities_filtered({name="lamp-light",area={{event.start_pos.x-0.1,event.start_pos.y-0.1},{event.start_pos.x+0.1,event.start_pos.y+0.1}}})) do
      light.teleport(lamp.position)
    end
  end
end


local function handlers()
  if remote.interfaces["PickerDollies"] and remote.interfaces["PickerDollies"]["dolly_moved_entity_id"] then
    script.on_event(remote.call("PickerDollies", "dolly_moved_entity_id"), move_lamp)
  end
	script.on_event({defines.events.on_built_entity, defines.events.on_robot_built_entity, defines.events.script_raised_built}, OnEntityCreated)
	script.on_event({defines.events.on_player_mined_entity, defines.events.on_robot_pre_mined, defines.events.on_entity_died, defines.events.script_raised_destroy}, OnEntityRemoved)
end

script.on_init(handlers)
script.on_load(handlers)
