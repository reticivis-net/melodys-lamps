local util = require("util");
local recipe_cost_factor = 3

local new_data = {}

local ingredients = {
    {"copper-cable", 5 * recipe_cost_factor},
    {"electronic-circuit", 2 * recipe_cost_factor}
}

if data.raw.recipe["constant-combinator"] ~= nil then
    ingredients = util.table.deepcopy(data.raw.recipe["constant-combinator"].ingredients)

    for _, ingredient in pairs(ingredients) do
        if ingredient.amount ~= nil then
            ingredient.amount = ingredient.amount * recipe_cost_factor
        else
            ingredient[2] = (ingredient[2] or 1) * recipe_cost_factor
        end
    end
end

table.insert(new_data, {
    enabled = false,
    type = "recipe",
    name = "larger-constant-combinator",
    ingredients = ingredients,
    result = "larger-constant-combinator"
})

local found_existing_technology = false

for _, technology in pairs(data.raw.technology) do
    if technology.effects ~= nil then
        for _, effect in pairs(technology.effects) do
            if effect.type == "unlock-recipe" and effect.recipe == "constant-combinator" then
                found_existing_technology = true

                table.insert(technology.effects, {
                    type = "unlock-recipe",
                    recipe = "larger-constant-combinator",
                })
            end
        end
    end
end

if not found_existing_technology then
    table.insert(new_data, {
        type = "technology",
        name = "larger-constant-combinator",
        icon_size = 128,
        icon = "__base__/graphics/technology/circuit-network.png",
        effects = {
            {
                type = "unlock-recipe",
                recipe = "larger-constant-combinator",
            }
        },
        unit = {
          count = 100,
          ingredients = {
                {"automation-science-pack", 1},
                {"logistic-science-pack", 1}
          },
          time = 15,
        },
        order = "a-d-d"
    })
end

data:extend(new_data)
