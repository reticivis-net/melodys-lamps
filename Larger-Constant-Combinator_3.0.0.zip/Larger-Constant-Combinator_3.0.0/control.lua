function make_sure_recipes_enabled()
	for _, force in pairs(game.forces) do
		for _, technology in pairs(force.technologies) do
			if technology.researched then
				for _, effect in pairs(technology.effects) do
					if effect.type == "unlock-recipe" and effect.recipe == "larger-constant-combinator" then
						force.recipes[effect.recipe].enabled = true
					end
				end
			end
		end
	end
end

script.on_init(make_sure_recipes_enabled)
script.on_configuration_changed(make_sure_recipes_enabled)
