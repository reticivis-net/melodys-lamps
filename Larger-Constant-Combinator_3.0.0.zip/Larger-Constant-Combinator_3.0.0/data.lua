
local combinator = {
    type = "constant-combinator",
    name = "larger-constant-combinator",
    icons = {
        {
            icon = "__base__/graphics/icons/constant-combinator.png",
            icon_size = 32,
        },
        {
            icon = "__Larger-Constant-Combinator__/graphics/plus.png",
            icon_size = 32,
        },
    },
    flags = {"placeable-neutral", "player-creation"},
    minable = {mining_time = 0.1, result = "larger-constant-combinator"},
    max_health = 120 * 2,
    corpse = "larger-constant-combinator-remnants",

    collision_box = {{-0.7, -0.7}, {0.7, 0.7}},
    selection_box = {{-1, -1}, {1, 1}},

    item_slot_count = settings.startup["Larger_Constant_Combinator_Rows"].value * 6,

    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },

    activity_led_light = {
        intensity = 0.8,
        size = 1,
        color = {r = 1.0, g = 1.0, b = 1.0}
    },

    activity_led_light_offsets = {
        {0.296875 * 2, -0.40625 * 2},
        {0.25 * 2, -0.03125 * 2},
        {-0.296875 * 2, -0.078125 * 2},
        {-0.21875 * 2, -0.46875 * 2}
    },

    circuit_wire_max_distance = 9 * 2,
}

combinator.sprites = make_4way_animation_from_spritesheet({
    layers = {
        {
            filename = "__base__/graphics/entity/combinator/hr-constant-combinator.png",
            width = 114,
            height = 102,
            frame_count = 1,
            shift = util.by_pixel(0 * 2, 5 * 2)
        },
        {
            filename = "__base__/graphics/entity/combinator/hr-constant-combinator-shadow.png",
            width = 98,
            height = 66,
            frame_count = 1,
            shift = util.by_pixel(8.5 * 2, 5.5 * 2),
            draw_as_shadow = true
        }
    }
})

combinator.activity_led_sprites = {
    north = {
        filename = "__base__/graphics/entity/combinator/activity-leds/hr-constant-combinator-LED-N.png",
        width = 14,
        height = 12,
        frame_count = 1,
        shift = util.by_pixel(9 * 2, -11.5 * 2)
    },
    east = {
        filename = "__base__/graphics/entity/combinator/activity-leds/hr-constant-combinator-LED-E.png",
        width = 14,
        height = 14,
        frame_count = 1,
        shift = util.by_pixel(7.5 * 2, -0.5 * 2)
    },
    south = {
        filename = "__base__/graphics/entity/combinator/activity-leds/hr-constant-combinator-LED-S.png",
        width = 14,
        height = 16,
        frame_count = 1,
        shift = util.by_pixel(-9 * 2, 2.5 * 2)
    },
    west = {
        filename = "__base__/graphics/entity/combinator/activity-leds/hr-constant-combinator-LED-W.png",
        width = 14,
        height = 16,
        frame_count = 1,
        shift = util.by_pixel(-7 * 2, -15 * 2)
    }
}

combinator.circuit_wire_connection_points = {
    {
        shadow = {
            red = util.by_pixel(7 * 2, -6 * 2),
            green = util.by_pixel(23 * 2, -6 * 2)
        },
        wire = {
            red = util.by_pixel(-8.5 * 2, -17.5 * 2),
            green = util.by_pixel(7 * 2, -17.5 * 2)
        }
    },
    {
        shadow = {
            red = util.by_pixel(32 * 2, -5 * 2),
            green = util.by_pixel(32 * 2, 8 * 2)
        },
        wire = {
            red = util.by_pixel(16 * 2, -16.5 * 2),
            green = util.by_pixel(16 * 2, -3.5 * 2)
        }
    },
    {
        shadow = {
            red = util.by_pixel(25 * 2, 20 * 2),
            green = util.by_pixel(9 * 2, 20 * 2)
        },
        wire = {
            red = util.by_pixel(9 * 2, 7.5 * 2),
            green = util.by_pixel(-6.5 * 2, 7.5 * 2)
        }
    },
    {
        shadow = {
            red = util.by_pixel(1 * 2, 11 * 2),
            green = util.by_pixel(1 * 2, -2 * 2)
        },
        wire = {
            red = util.by_pixel(-15 * 2, -0.5 * 2),
            green = util.by_pixel(-15 * 2, -13.5 * 2)
        }
    }
}

local item = {
    type = "item",
    name = "larger-constant-combinator",
    icons = {
        {
            icon = "__base__/graphics/icons/constant-combinator.png",
            icon_size = 64,
        },
        {
            icon = "__Larger-Constant-Combinator__/graphics/plus.png",
            icon_size = 32,
        },
    },
    subgroup = "circuit-network",
    place_result="larger-constant-combinator",
    order = "c[combinators]-c[constant-combinator]-larger",
    stack_size = 25,
}

local corpse = {
    type = "corpse",
    name = "larger-constant-combinator-remnants",
    icons = {
        {
            icon = "__base__/graphics/icons/constant-combinator.png",
            icon_size = 32,
        },
        {
            icon = "__Larger-Constant-Combinator__/graphics/plus.png",
            icon_size = 32,
        },
    },
    flags = {"placeable-neutral", "not-on-map"},
    selection_box = {{-1, -1}, {1, 1}},
    tile_width = 2,
    tile_height = 2,
    selectable_in_game = false,
    subgroup = "remnants",
    order="d[remnants]-a[generic]-a[small]",
    time_before_removed = 60 * 60 * 15, -- 15 minutes
    final_render_layer = "remnants",
    remove_on_tile_placement = false,
    animation = make_rotated_animation_variations_from_sheet(1, {
        filename = "__base__/graphics/entity/combinator/remnants/constant/hr-constant-combinator-remnants.png",
        line_length = 1,
        width = 118,
        height = 112,
        frame_count = 1,
        variation_count = 1,
        axially_symmetrical = false,
        direction_count = 4,
        shift = util.by_pixel(0, 0),
    })
  }

data:extend({
    item,
    combinator,
    corpse,
})
